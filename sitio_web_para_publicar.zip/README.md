# Stand-Speed-Connections-2026 – Tarjetas digitales

Sitio estático con una página por tarjeta del stand de Innovación y Propiedad Industrial de la Cámara de Comercio del Huila.
Cada código QR impreso apunta a la página de su tarjeta.

## Despliegue en Vercel
1. En Vercel: **Add New → Project → Import** este repositorio.
2. Framework preset: **Other**. Sin comando de build. Output directory: `./` (raíz).
3. Deploy. `vercel.json` activa URLs limpias: `https://<dominio>/t01`, `https://<dominio>/t02`, …

## Enlace por tarjeta
| N.º | Página del Word | Tarjeta | Radicado | Ruta |
|---|---|---|---|---|
| 1 | 1 | PATENTE - AIRWAYFLEX | NC2026/0003395 | `/t01` |
| 2 | 2 | PATENTE - LARINGOCEL | NC2022/0010319 | `/t02` |
| 3 | 3 | PATENTE – SOPORTE CON ESTRIBO | NC2020/0012382 | `/t03` |
| 4 | 3 | PATENTE – TIPO MANTA | NC2023/0013042 | `/t04` |
| 5 | 4 | PATENTE - LARINGOCEL | NC2023/0018502 | `/t05` |
| 6 | 5 | PATENTE – FORMULA ENFOSCADOS DE PARED | NC2024/0001678 | `/t06` |
| 7 | 6 | PATENTE – MÁQUINA MODULAR PARA CLASIFICACIÓN DE GRANOS DE CAFÉ | NC2024/0009441 | `/t07` |
| 8 | 7 | PATENTE – SISTEMA DE CONTROL DE OLORES | NC2024/0013637 | `/t08` |
| 9 | 8 | PATENTE – ESTUFA ECO-EFICIENTE | NC2017/0008373 | `/t09` |
| 10 | 9 | PATENTE – SISTEMA DE CONTROL DE OLORES | NC2023/0008649 | `/t10` |
| 11 | 10 | PATENTE – MÁQUINA DESFIBRADO FINO DE PENCAS | NC2024/0003879 | `/t11` |
| 12 | 11 | PATENTE – COMPOSTERAS | NC2021/0017533 | `/t12` |
| 13 | 12 | PATENTE – ALFAJÍAS EN POLIESTIRENO EXPANDIDO | NC2025/0009562 | `/t13` |
| 14 | 13 | PATENTE – PERSONAJES CÓMICS | NC2026/0008668 – NC2026/0008670 | `/t14` |
| 15 | 14 | PATENTE – COMPOSTERAS | NC2019/0014675 | `/t15` |
| 16 | 15 | MARCA – ROBOKIDS | SD2025/0089253 | `/t16` |
| 17 | 16 | PATENTE – MEDIDOR INTELIGENTE | NC2019/0013907 | `/t17` |
| 18 | 17 | MARCA – DE DÁTIL ENERGY | NC2019/0013907 | `/t18` |
| 19 | 18 | MARCA – NIAFLEZ BY ESTEFANIA AMAR | SD2025/0089837 | `/t19` |
| 20 | 19 | MARCA – PALMARITO COFFEE | SD2025/0089837 | `/t20` |
| 21 | 20 | MARCA – CHAPURO COFFEE | SD2022/0067358 | `/t21` |
| 22 | 21 | MARCA – ROSSE PASTEL | SD2025/0035541 | `/t22` |

`/` (index) lista todas las tarjetas.
